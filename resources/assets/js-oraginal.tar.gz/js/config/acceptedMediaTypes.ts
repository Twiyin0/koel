export const acceptedMediaTypes = [
  'audio/flac',
  'audio/mp3',
  'audio/mpeg',
  'audio/ogg',
  'audio/x-flac',
  'audio/x-aac'
]
